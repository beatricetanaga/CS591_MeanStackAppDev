import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  flickrTag: string;
  constructor(private httpClient: HttpClient) {
  }
  // title = 'PS6';

  get_images(): any {
    return this.httpClient.get('/api/ps4/' + this.flickrTag).subscribe(function(res) {
      console.log(res);
      this.photos = res.photos.photo;
    });
  }
}
